import {BasicColumn} from '/@/components/Table';
import {FormSchema} from '/@/components/Table';
import { rules} from '/@/utils/helper/validator';
import { render } from '/@/utils/common/renderUtils';
import { getWeekMonthQuarterYear } from '/@/utils';
//列表数据
export const columns: BasicColumn[] = [
  {
    title: '卡号',
    align:"center",
    dataIndex: 'cardNo'
  },
  {
    title: '短号',
    align:"center",
    dataIndex: 'shortNo'
  },
  {
    title: '接入号',
    align:"center",
    dataIndex: 'joinNo'
  },
  {
    title: '是否实名',
    align:"center",
    dataIndex: 'named_dictText'
  },
  {
    title: '本周期上传量',
    align:"center",
    dataIndex: 'upBytes'
  },
  {
    title: '本周期下载量',
    align:"center",
    dataIndex: 'downBytes'
  },
];

//子表列表数据
export const cardPackageRelColumns: BasicColumn[] = [
  {
    title: '卡片',
    align:"center",
    dataIndex: 'cardId_dictText'
  },
  {
    title: '套餐',
    align:"center",
    dataIndex: 'packageId_dictText'
  },
  {
    title: '开始时间',
    align:"center",
    dataIndex: 'startTime',
    customRender:({text}) =>{
      return !text?"":(text.length>10?text.substr(0,10):text)
    },
  },
  {
    title: '结束时间',
    align:"center",
    dataIndex: 'endTime',
    customRender:({text}) =>{
      return !text?"":(text.length>10?text.substr(0,10):text)
    },
  },
  {
    title: '状态',
    align:"center",
    dataIndex: 'status_dictText'
  },
];

// 高级查询数据
export const superQuerySchema = {
  cardNo: {title: '卡号',order: 0,view: 'text', type: 'string',},
  shortNo: {title: '短号',order: 1,view: 'text', type: 'string',},
  joinNo: {title: '接入号',order: 2,view: 'text', type: 'string',},
  named: {title: '是否实名',order: 3,view: 'number', type: 'number',dictCode: 'card_isnamed',},
  upBytes: {title: '本周期上传量',order: 4,view: 'number', type: 'number',},
  downBytes: {title: '本周期下载量',order: 5,view: 'number', type: 'number',},
};
