package org.jeecg.modules.cpe.device.service.impl;

import org.jeecg.modules.cpe.card.service.ICardInfoService;
import org.jeecg.modules.cpe.device.entity.CpeDevice;
import org.jeecg.modules.cpe.device.entity.CpeDeviceNeighbor;
import org.jeecg.modules.cpe.device.entity.CpeDeviceStatus;
import org.jeecg.modules.cpe.device.mapper.CpeDeviceStatusMapper;
import org.jeecg.modules.cpe.device.service.ICpeDeviceNeighborService;
import org.jeecg.modules.cpe.device.service.ICpeDeviceService;
import org.jeecg.modules.cpe.device.service.ICpeDeviceStatusService;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Description: CPE设备状态表
 * @Author: jeecg-boot
 * @Date:   2024-12-25
 * @Version: V1.0
 */
@Service
public class CpeDeviceStatusServiceImpl extends ServiceImpl<CpeDeviceStatusMapper, CpeDeviceStatus> implements ICpeDeviceStatusService {
	
	@Autowired
	private CpeDeviceStatusMapper cpeDeviceStatusMapper;
	@Autowired
	private ICpeDeviceService cpeDeviceService;
	@Autowired
	private ICpeDeviceNeighborService cpeDeviceNeighborService;
	@Autowired
	private ICardInfoService cardInfoService;

	private int sim_slot = 0;
	private String imei = "";
	private String version = "";
	private String iccid = "";
	private String module = "";
	private String lte_cell = "";
	private String lte_cainfo = "";
	private String lte_cops = "";
	private String uptime = "";
	private String ipv4 = "";
	private String ipv6 = "";
	private String upBytes = "";
	private String downBytes = "";
	private String deviceSn = "";
	private String dns1 = "";
	private String dns2 = "";
	
	@Override
	public List<CpeDeviceStatus> selectByMainId(String mainId) {
		return cpeDeviceStatusMapper.selectByMainId(mainId);
	}

	@Override
	public void deleteByMainId(String mainId) {
		cpeDeviceStatusMapper.deleteByMainId(mainId);
	}

	private String bandwidth(String str)
	{
		if (str.equals(""))
			return "";

		String bandwidth = "";
		switch (str) {
			case "6":
				bandwidth = "1.4 MHz";
				break;

			case "15":
				if (lte_cell.indexOf("NR service cell") > 0)
					bandwidth = "15 MHz";
				else
					bandwidth = "3 MHz";
				break;
		
			case "25":
				if (lte_cell.indexOf("NR service cell") > 0)
					bandwidth = "25 MHz";
				else
					bandwidth = "5 MHz";
				break;

			case "50":
				if (lte_cell.indexOf("NR service cell") > 0)
					bandwidth = "50 MHz";
				else
					bandwidth = "10 MHz";
				break;

			case "75":
				bandwidth = "15 MHz";
				break;

			case "100":
				if (lte_cell.indexOf("NR service cell") > 0)
					bandwidth = "100 MHz";
				else
					bandwidth = "20 MHz";
				break;

			default:
				bandwidth = str + " MHz";
				break;
		}
		return bandwidth;
	}

	private String rat(String str)
	{
		if (str.equals(""))
			return "";

		String rat = "";
		switch (str) {
			case "1":
				rat = "GSM";
				break;

			case "2":
				rat = "WCDMA";
				break;

			case "3":
				rat = "TDSCDMA";
				break;

			case "4":
				rat = "LTE";
				break;

			case "5":
				rat = "eMTC";
				break;

			case "6":
				rat = "NB-IoT";
				break;

			case "7":
				rat = "CDMA";
				break;

			case "8":
				rat = "EVDO";
				break;

			case "9":
				rat = "NR-RAN";
				break;

			default:
				rat = "Unknow";
				break;
		}

		return rat;
	}

	private String ssSinr(String str)
	{
		if (str.equals(""))
			return "";

		String sinr = "";

		switch (str) {
			case "0":
				sinr = "<-23dB";
				break;

			case "127":
				sinr = ">40dB";
				break;

			case "255":
				sinr = "UnKnow";
				break;

			default:
				sinr = String.valueOf((Integer.parseInt(str) * 0.5 - 23)) + "dB";
				break;
		}

		return sinr;
	}

	private String ssRsrp(String str)
	{
		if (str.equals(""))
			return "";

		String rsrp = "";

		switch (str) {
			case "0":
				rsrp = "<-156dBm";
				break;

			case "126":
				rsrp = ">-31dBm";
				break;

			case "255":
				rsrp = "UnKnow";
				break;

			default:
				rsrp = String.valueOf((Integer.parseInt(str) * 1 - 156)) + "dBm";
				break;
		}

		return rsrp;
	}

	private String ssRsrq(String str)
	{
		if (str.equals(""))
			return "";
			
		String rsrq = "";

		switch (str) {
			case "0":
				rsrq = "<-43dB";
				break;

			case "255":
				rsrq = "UnKnow";
				break;

			default:
				rsrq = String.valueOf((Integer.parseInt(str) * 0.5 - 43)) + "dB";
				break;
		}

		return rsrq;
	}

	private void service_nr(CpeDevice cpeDevice, CpeDevice newCpeDevice, String ipAddrParam, String lteStatus) throws Exception
	{
		String nr_info = lte_cell.split("\\r\\n")[3];
		String[] items = nr_info.split(",");

		String isServiceCell = items[0];
		newCpeDevice.setDeviceStatusNo(isServiceCell);

		String rat = rat(items[1]);
		String mcc = items[2];
		String mnc = items[3];
		String tac = items[4];
		String cellid = items[5];
		String narfcn = items[6];
		String physicalcellId = items[7];
		String band = items[8];
		// if (lte_cell.indexOf("NR service cell") == -1)
		// 	band += "Mhz";
		newCpeDevice.setOnlineBand(band);
		String bandwidth = bandwidth(items[9]);

		String sinr = ssSinr(items[10]);
		String rxlev = items[11];
		String rsrp = ssRsrp(items[12]);
		String rsrq = ssRsrq(items[13]);

		String cops = "";
		if (lte_cops != null && lte_cops.length() > 0)
		{
			try
			{
				String[] cops_items = lte_cops.split("\\r\\n");
				cops = cops_items[1].split(",")[2].replace("\\\"", "");
				if (cops.indexOf("UNICOM") > 0)
					newCpeDevice.setOnlineNetNo("unicom");
				if (cops.indexOf("TELECOM") > 0)
					newCpeDevice.setOnlineNetNo("telecom");
				if (cops.indexOf("MOBILE") > 0)
					newCpeDevice.setOnlineNetNo("mobile");
				if (cops.indexOf("BROADNET") > 0)
					newCpeDevice.setOnlineNetNo("board");
			}catch (Exception ex) {}
		}

		cpeDeviceService.updateById(newCpeDevice);

		String caBand = "";
		if (lte_cainfo != null && lte_cainfo.length() > 0)
		{
			if (lte_cainfo.split("\\r\\n").length > 2)
			{
				try
				{
					String[] cainfo_items = lte_cainfo.split("\\r\\n")[2].split(",")[0].split(":");
					if (cainfo_items[0].equals("PCC"))
					{
						caBand = cainfo_items[1];
					}
				}catch (Exception ex) {}
			}
		}

		if (ipAddrParam != null && ipAddrParam.length() > 0)
		{
			String[] ipaddr = ipAddrParam.split(",");
			ipv4 = ipaddr[0];
			ipv6 = ipaddr[1];
			upBytes = ipaddr[2];
			downBytes = ipaddr[3];
		}

		if (lteStatus != null && !lteStatus.isEmpty()) {
			try {
				ObjectMapper objectMapper = new ObjectMapper();
				@SuppressWarnings("unchecked")
				Map<String, Object> lteStatusMap = objectMapper.readValue(lteStatus, Map.class);

				uptime = lteStatusMap.containsKey("uptime") ? lteStatusMap.get("uptime").toString() : uptime;
				if (lteStatusMap.containsKey("dns-server")) {
					@SuppressWarnings("unchecked")
					ArrayList<String> dnsList = (ArrayList<String>) (lteStatusMap.get("dns-server"));

					if (dnsList.size() > 0)
					{
						dns1 = dnsList.get(0).toString();

						if (dnsList.size() > 1)
							dns2 = dnsList.get(1).toString();
					}
				}
			} catch (IOException e) {
				log.error("Error parsing lteStatus JSON", e);
				throw new Exception("JSON解析错误！");
			}
		}

		CpeDeviceStatus cpeDeviceStatus = new CpeDeviceStatus();
		cpeDeviceStatus.setIpv4(ipv4);
		cpeDeviceStatus.setIpv6(ipv6);
		cpeDeviceStatus.setUptime(uptime);
		cpeDeviceStatus.setUpBytes(upBytes);
		cpeDeviceStatus.setDownBytes(downBytes);
		cpeDeviceStatus.setCops(cops);
		cpeDeviceStatus.setOnlineBand(band);
		cpeDeviceStatus.setCaBand(caBand);
		cpeDeviceStatus.setCellId(cellid);
		cpeDeviceStatus.setCpeId(cpeDevice.getId());
		cpeDeviceStatus.setDeviceSn(deviceSn);
		cpeDeviceStatus.setIccid(iccid);
		cpeDeviceStatus.setImei(imei);
		cpeDeviceStatus.setLinkStatus(isServiceCell);
		cpeDeviceStatus.setMcc(mcc);
		cpeDeviceStatus.setMnc(mnc);
		cpeDeviceStatus.setModemVersion(version);
		cpeDeviceStatus.setPcid(physicalcellId);
		cpeDeviceStatus.setRsrp(rsrp);
		cpeDeviceStatus.setRsrq(rsrq);
		cpeDeviceStatus.setSimSlot(sim_slot);
		cpeDeviceStatus.setSinr(sinr);
		cpeDeviceStatus.setStatus(isServiceCell);
		cpeDeviceStatus.setTac(tac);
		cpeDeviceStatus.setBandwidth(bandwidth);
		cpeDeviceStatus.setArfcn(narfcn);
		cpeDeviceStatus.setRxlev(rxlev);
		cpeDeviceStatus.setRat(rat);
		cpeDeviceStatus.setSysOrgCode("A01");
		cpeDeviceStatus.setTs(new Date());
		cpeDeviceStatus.setCreateBy("admin");
		cpeDeviceStatus.setCreateTime(new Date());
		cpeDeviceStatus.setUpdateBy("admin");
		cpeDeviceStatus.setUpdateTime(new Date());
		cpeDeviceStatus.setDns1(dns1);
		cpeDeviceStatus.setDns2(dns2);

		save(cpeDeviceStatus);

		String[] ne_info;
		if (lte_cell.indexOf("NR neighbor cell:") > 0)
			ne_info = lte_cell.substring(lte_cell.indexOf("NR neighbor cell:") + 2, lte_cell.length()).split("\\r\\n");
		else
		ne_info = lte_cell.substring(lte_cell.indexOf("LTE neighbor cell:") + 2, lte_cell.length()).split("\\r\\n");
		cpeDeviceNeighborService.deleteByMainId(cpeDevice.getId());
		if (ne_info.length > 1)
		{
			Collection<CpeDeviceNeighbor> cpeDeviceNeighborList = new ArrayList<>();
			for (int i = 1; i < ne_info.length - 2; i++)
			{
				String[] ne_items = ne_info[i].split(",");
				String ne_isServiceCell = ne_items[0];
				String ne_rat = rat(ne_items[1]);
				String ne_mcc = ne_items[2];
				String ne_mnc = ne_items[3];
				String ne_tac = ne_items[4];
				String ne_cellid = ne_items[5];
				String ne_narfcn = ne_items[6];
				String ne_physicalcellId = ne_items[7];
				String ne_sinr = ssSinr(ne_items[8]);
				String ne_rxlev = ne_items[9];
				String ne_rsrp = ssRsrp(ne_items[10]);
				String ne_rsrq = ssRsrq(ne_items[11]);

				CpeDeviceNeighbor cpeDeviceNeighbor = new CpeDeviceNeighbor();
				cpeDeviceNeighbor.setCpeId(cpeDevice.getId());
				cpeDeviceNeighbor.setArfcn(ne_narfcn);
				cpeDeviceNeighbor.setCellid(ne_cellid);
				cpeDeviceNeighbor.setMcc(ne_mcc);
				cpeDeviceNeighbor.setMnc(ne_mnc);
				cpeDeviceNeighbor.setPhysicalcellid(ne_physicalcellId);
				cpeDeviceNeighbor.setRat(ne_rat);
				cpeDeviceNeighbor.setRsrp(ne_rsrp);
				cpeDeviceNeighbor.setRsrq(ne_rsrq);
				cpeDeviceNeighbor.setRxlev(ne_rxlev);
				if (lte_cell.indexOf("NR service cell") >0)
					cpeDeviceNeighbor.setSinr(ne_sinr);
				cpeDeviceNeighbor.setStatus(ne_isServiceCell);
				cpeDeviceNeighbor.setTac(ne_tac);
				cpeDeviceNeighbor.setCreateBy("admin");
				cpeDeviceNeighbor.setCreateTime(new Date());
				cpeDeviceNeighbor.setUpdateBy("admin");
				cpeDeviceNeighbor.setUpdateTime(new Date());
				cpeDeviceNeighbor.setSysOrgCode("A01");

				cpeDeviceNeighborList.add(cpeDeviceNeighbor);
			}
			cpeDeviceNeighborService.saveBatch(cpeDeviceNeighborList);
		}
	}

	public void push(String deviceSnParam, String ubusOutputParam, String ipAddrParam, String lteStatus) throws Exception
	{
		deviceSn = deviceSnParam.replace(":", "").toUpperCase();
		List<CpeDevice> cpeDeviceList = cpeDeviceService.selectByDeviceSn(deviceSn);
		CpeDevice cpeDevice = cpeDeviceList.isEmpty() ? null : cpeDeviceList.get(0);
		if (cpeDevice == null) {
			throw new Exception("设备未找到！");
		}
		
		cpeDevice.setDeviceStatusNo("1");

		if (ubusOutputParam != null) {
			String ubusOutput = ubusOutputParam;
			try {
				ObjectMapper objectMapper = new ObjectMapper();
				@SuppressWarnings("unchecked")
				Map<String, Object> ubusOutputMap = objectMapper.readValue(ubusOutput, Map.class);
					
				sim_slot = Integer.parseInt(ubusOutputMap.get("LTE_SIMSLOT").toString());

				imei = ubusOutputMap.containsKey("LTE_IMEI") ? ubusOutputMap.get("LTE_IMEI").toString() : "";
				version = ubusOutputMap.containsKey("LTE_VER") ? ubusOutputMap.get("LTE_VER").toString() : "";
				iccid = ubusOutputMap.containsKey("LTE_ICCID") ? ubusOutputMap.get("LTE_ICCID").toString() : "";
				
				if (cardInfoService.selectByCardNo(iccid).size() > 0)
				{
					cpeDevice.setCardNo(cardInfoService.selectByCardNo(iccid).get(0).getId());
					cpeDevice.setOnlineCardNo(cardInfoService.selectByCardNo(iccid).get(0).getId());
				}
				module = ubusOutputMap.containsKey("LTE_MODULE") ? ubusOutputMap.get("LTE_MODULE").toString() : "";

				lte_cell = ubusOutputMap.containsKey("LTE_CELL") ? ubusOutputMap.get("LTE_CELL").toString() : "";
				lte_cainfo = ubusOutputMap.containsKey("LTE_CAINFO") ? ubusOutputMap.get("LTE_CAINFO").toString() : "";
				lte_cops = ubusOutputMap.containsKey("LTE_COPS") ? ubusOutputMap.get("LTE_COPS").toString() : "";

				if (lte_cell != null && lte_cell.length() > 0)
				{
					//5G信号
					if ((lte_cell.indexOf("NR service cell") > 0)
				 		|| (lte_cell.indexOf("LTE service cell") > 0)
						|| (lte_cell.indexOf("LTE-NR EN-DC service cell") > 0))
					{
						service_nr(cpeDevice, cpeDevice, ipAddrParam, lteStatus);
					}
				}
			} catch (IOException e) {
				log.error("Error parsing ubusOutput JSON", e);
				throw new Exception("JSON解析错误！");
			}
		}

		cpeDeviceService.updateById(cpeDevice);
	}

	public void deleteByTs(Date deleteBeforTime){
		cpeDeviceStatusMapper.deleteByTs(deleteBeforTime);
	}

	/**
	 * 通过主表id查询子表最新时间戳
	 *
	 * @param deleteBeforTime 删除此时间前的数据
	 * @return void
	 */
	public Date selectNewtestTsByMainId(String mainId){
		return cpeDeviceStatusMapper.selectNewtestTsByMainId(mainId);
	}
}
