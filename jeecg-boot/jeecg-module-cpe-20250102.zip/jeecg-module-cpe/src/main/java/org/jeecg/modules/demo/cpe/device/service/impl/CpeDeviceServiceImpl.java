package org.jeecg.modules.demo.cpe.device.service.impl;

import org.jeecg.modules.demo.cpe.device.entity.CpeDevice;
import org.jeecg.modules.demo.cpe.device.mapper.CpeDeviceMapper;
import org.jeecg.modules.demo.cpe.device.service.ICpeDeviceService;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

/**
 * @Description: 设备信息表
 * @Author: jeecg-boot
 * @Date:   2024-12-30
 * @Version: V1.0
 */
@Service
public class CpeDeviceServiceImpl extends ServiceImpl<CpeDeviceMapper, CpeDevice> implements ICpeDeviceService {

}
