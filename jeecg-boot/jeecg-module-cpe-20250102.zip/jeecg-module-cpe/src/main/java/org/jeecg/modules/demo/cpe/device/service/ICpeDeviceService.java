package org.jeecg.modules.demo.cpe.device.service;

import org.jeecg.modules.demo.cpe.device.entity.CpeDevice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Description: 设备信息表
 * @Author: jeecg-boot
 * @Date:   2024-12-30
 * @Version: V1.0
 */
public interface ICpeDeviceService extends IService<CpeDevice> {

}
